package br.com.willaimsilva.primeiroapp

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class Counter:ViewModel(){
    private var _count = MutableLiveData (0)
    val count:LiveData<Int>
    get() = _count
    fun increment(){ _count.postValue(count.value!!+1)}


}
