package br.com.willaimsilva.primeiroapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.lifecycle.ViewModelProvider
import br.com.willaimsilva.primeiroapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val tag = "APPDBUG"
    private lateinit var binding: ActivityMainBinding
    private lateinit var counter: Counter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        Log.d(tag, "Evento onCreate")

        binding = ActivityMainBinding.inflate(layoutInflater)
        binding.BtmCount.setOnClickListener {
            counter.increment() // valor atual mais um

        }
        counter = ViewModelProvider(this).get(counter::class.java)
counter.count.observe(this){
    number ->binding.TvCounter.text = (number.toString())
}
    }

    override fun onStop() {
        super.onStop()
        Log.d(tag, "Evento onStop")
    }

    override fun onStart() {
        super.onStart()
        Log.d(tag, "onStart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(tag, "onDestroy")
    }
}

